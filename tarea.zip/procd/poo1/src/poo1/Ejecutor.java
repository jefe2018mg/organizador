/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poo1;

import java.util.Scanner;

public class Ejecutor {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        teren t1 = new teren(20,30.5, 123);
        t1.calcularArea();
        t1.calcularCosto_t();
        System.out.println(t1);

    }
}

class teren {

    public double cost;
    public double ancho;
    public double largo;
    public double area;
    public double valor2;

    public teren(double valor2, double ancho, double largo) {
        this.valor2 = valor2;
        this.ancho = ancho;
        this.largo = largo;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public void setAncho(double ancho) {
        this.ancho = ancho;
    }

    public void setLargo(double largo) {
        this.largo = largo;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public void setValorm2(double valorm2) {
        this.valor2 = valor2;
    }

    public double getCosto_t() {
        return this.cost;
    }

    public double getAncho() {
        return this.ancho;
    }

    public double getLargo() {
        return this.largo;
    }

    public double getArea() {
        return this.area;
    }

    public double getValorm2() {
        return this.valor2;
    }

    public void calcularArea() {
        this.area = this.ancho * this.largo;
    }

    public void calcularCosto_t() {
        this.cost = this.area * this.valor2;
    }

    public String toString() {
        return String.format("Terreno con area: %.2f\nTiene un valor por m2: de %.2f\nCon un costo total de: %.2f"
                + ""
                + "", this.area, this.valor2, this.cost);
    }
}
