package poo1;


import java.util.Scanner;

public class testpersonas {

    public static void main(String arg[]) {
        Scanner teclado = new Scanner(System.in);
        persona p1 = new persona();
        persona p2 = new persona("Henry", 21, 1500);
        persona p3 = new persona();
        System.out.println("sueldo de persona 1: " + p1.getsueldo());
        System.out.println("sueldo de persona 2: " + p2.getsueldo());
        System.out.print("Deme su nombre: ");
        p3.setNombre(teclado.nextLine());
        System.out.print("Deme su edad: ");
        p3.setEdad(teclado.nextInt());
        System.out.print("Deme su sueldo: ");
        p3.setSueldo(teclado.nextDouble());
        //System.out.println("p3 es :"+p3.getNombre()+","+p3.getEdad()+","+p3.getsueldo());
        p3.reCalcularsueldo();
        System.out.println(p3);
        //System.out.println("p3 es :"+p3.getNombre()+","+p3.getEdad()+","+p3.getsueldo());
    }
}

class persona {

    public String nombre;
    private int edad;
    private double sueldo;

    public persona() {
    }

    public persona(String nombre, int edad, double sueldo) {
        this.nombre = nombre;
        this.edad = edad;
        this.sueldo = sueldo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public String getNombre() {
        return this.nombre;
    }

    public int getEdad() {
        return this.edad;
    }

    public double getsueldo() {
        return this.sueldo;
    }

    public void reCalcularsueldo() {
        this.sueldo = (this.edad >= 18) ? this.sueldo * 1.1 : this.sueldo * 1.05;
    }

    public String toString() {
        return String.format("Nombre: %s\nEdad: %d \nSueldo:%.2f", this.nombre, this.edad, this.sueldo);
    }

}
 
//sobre carga de metodos se llama el tema 
