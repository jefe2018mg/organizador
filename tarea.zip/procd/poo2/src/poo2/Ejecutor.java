
package poo2;
public class Ejecutor {
    
    public static void main(String[] args) {
        EquivalenteHora h1 = new EquivalenteHora(5);
        System.out.println(h1);
    }
}

 class EquivalenteHora {
    public int horas;
    public int minutos;
    public int segundos;
    public double dias;

    public EquivalenteHora(int horas) {
        this.horas = horas;
        this.minutos = horas * 60;
        this.segundos = horas * 3600;
        this.dias = horas / 24.0;
    }

    public EquivalenteHora(int horas, int minutos, int segundos, double dias) {
        this.horas = horas;
        this.minutos = minutos;
        this.segundos = segundos;
        this.dias = dias;
    }

 
    public String toString() {
        return "Horas: " + horas + "\n" +"Minutos: " + minutos + "\n" +"Segundos: " + segundos + "\n" +"Dias: " + dias;
    }
}



