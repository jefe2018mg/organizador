/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo3;

public class Ejecutor {
    public static void main(String[] args) {
        InstitucionEducativa institucioneducativa = new InstitucionEducativa("ITSDAB"
                ,"Fiscomisional", 1230, 600, 6
                , 80);
        System.out.println(institucioneducativa);
        System.out.println("El presupuesto es: "+institucioneducativa.presupuesto());

    }
}

    
    
