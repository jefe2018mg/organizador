
package poo3;

public class InstitucionEducativa {

    private String nombre;
    private String tipo;
    private int numAlumnos;
    private int numDocentes;
    private int numSedes;
    private double gastAlumnos;

    public InstitucionEducativa(String nombre, String tipo, int numAlumnos, int numDocentes, int numSedes, double gastAlumnos) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.numAlumnos = numAlumnos;
        this.numDocentes = numDocentes;
        this.numSedes = numSedes;
        this.gastAlumnos = gastAlumnos;
    }

    public double presupuesto() {
        return this.gastAlumnos * this.numAlumnos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getNumAlumnos() {
        return numAlumnos;
    }

    public void setNumAlumnos(int numeroAlumnos) {
        this.numAlumnos = numAlumnos;
    }

    public int getNumDocentes() {
        return numDocentes;
    }

    public void setNumDocentes(int numeroDocentes) {
        this.numDocentes = numDocentes;
    }

    public int getNumSedes() {
        return numSedes;
    }

    public void setNumSedes(int numeroSedes) {
        this.numSedes = numeroSedes;
    }

    public double getGastAlumnos() {
        return gastAlumnos;
    }

    public void setGastAlumnos(double gastoAlumnos) {
        this.gastAlumnos = gastoAlumnos;
    }

    public String toString() {
        return "InstitucionEducativa{" + "nombre=" + nombre + ", tipo=" + tipo 
                + ", numeroAlumnos=" + numAlumnos + ", numeroDocentes="
                + numDocentes + ", numeroSedes=" + numSedes
                + ", gastoAlumnos=" + gastAlumnos + '}';
    }

}
