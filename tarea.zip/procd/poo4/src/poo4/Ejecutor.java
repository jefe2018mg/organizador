
package poo4;
import java.util.Scanner;
public class Ejecutor {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el sistema operativo del equipo:");
        String sistemaOperativo = scanner.nextLine();
        System.out.println("Ingrese el tamaño de pantalla del equipo:");
        double tamañoPantalla = scanner.nextDouble();
        System.out.println("Ingrese el costo inicial del equipo:");
        double costoInicial = scanner.nextDouble();
        System.out.println("Ingrese el porcentaje de IVA del equipo:");
        double ivaPorcentaje = scanner.nextDouble();
        System.out.println("Ingrese la dirección MAC del equipo:");
        String direccionMAC = scanner.next();
        System.out.println("Ingrese la información IMEI del equipo:");
        String imei = scanner.next();

        EquipoCelular equipo = new EquipoCelular(sistemaOperativo, tamañoPantalla, costoInicial, ivaPorcentaje, direccionMAC, imei);

        System.out.println("\nDetalles del Equipo Celular:");
        System.out.println(equipo);

    }
}

class EquipoCelular {

    public String sistmOperativo;
    public double tamPantalla;
    public double costInicial;
    public double ivaPorcentaje;
    public String dirMAC;
    public String imei;

    public EquipoCelular(String sistmOperativo, double tamPantalla, double costInicial, double ivaPorcentaje, String dirMAC, String imei) {
        this.sistmOperativo = sistmOperativo;
        this.tamPantalla = tamPantalla;
        this.costInicial = costInicial;
        this.ivaPorcentaje = ivaPorcentaje;
        this.dirMAC = dirMAC;
        this.imei = imei;
    }

    public double calcularCostFinal() {
        return costInicial * (1 + ivaPorcentaje / 100);
    }

    @Override
    public String toString() {
        return "Sistema Operativo: " + sistmOperativo
                + "\nTamano de Pantalla: " + tamPantalla + " pulgadas"
                + "\nCosto Inicial: $" + costInicial
                + "\nPorcentaje de IVA: " + ivaPorcentaje + "%"
                + "\nCosto Final: $" + calcularCostFinal()
                + "\nDirecciodsn MAC: " + dirMAC
                + "\nIMEI: " + imei;
    }
}
