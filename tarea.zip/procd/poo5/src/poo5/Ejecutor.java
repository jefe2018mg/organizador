package poo5;

import java.util.Random;

public class Ejecutor {

    public static void main(String[] args) {
        Estudiante estudiante = new Estudiante(generarNombreAleatorio(), generarCalificaAleatoria(), generarCalificaAleatoria(), generarCalificaAleatoria());

        System.out.println(estudiante);
    }

    public static String generarNombreAleatorio() {
        String[] nombres = {"jose", "pablo", "andres", "pedro", "jeis", "juan", "carlos", "lucas", "kico", "penelope"};
        String[] apellidos = {"joan", "genry", "pineda", "samaniego", "lolita", "tonci", "maci", "raquel", "santiago", "sofi"};

        Random rand = new Random();
        String nombre = nombres[rand.nextInt(nombres.length)];
        String apellido = apellidos[rand.nextInt(apellidos.length)];

        return nombre + " " + apellido;
    }

    public static double generarCalificaAleatoria() {
        Random rand = new Random();
        return rand.nextDouble() * 10;
    }
}

class Estudiante {

    public String nombre;
    public double calificaMateria1;
    public double calificaMateria2;
    public double calificaMateria3;
    public double promedio;
    public String estado;

    public Estudiante(String nombre, double calificaMateria1, double calificaMateria2, double calificaMateria3) {
        this.nombre = nombre;
        this.calificaMateria1 = calificaMateria1;
        this.calificaMateria2 = calificaMateria2;
        this.calificaMateria3 = calificaMateria3;
        this.promedio = calcularPromedio();
        this.estado = determinarEstado();
    }

    public double calcularPromedio() {
        return (calificaMateria1 + calificaMateria2 + calificaMateria3) / 3;
    }

    public String determinarEstado() {
        return promedio >= 6.9 ? "Aprobado" : "Reprobado";
    }

    @Override
    public String toString() {
        return String.format("Nombre del estudiante: %s\n"
                + "Calificacion 1: %.2f\nCalificacion"+ " 2: %.2f\nCalificacion 3: %.2f\nPromedio de : %.2f\n"
                + "Estado del alumno: %s", nombre, calificaMateria1, calificaMateria2,
                calificaMateria3, promedio, estado);
    }
}
