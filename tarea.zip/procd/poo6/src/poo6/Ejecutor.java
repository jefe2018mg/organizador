
package poo6;
public class Ejecutor {

    public static void main(String[] args) {

        Profesor profesor1 = new Profesor("Hery", "Ramires", 4000, "985424");

        System.out.println(profesor1);
    }
}

class Profesor {

    public String nombre;
    public String apellido;
    public double suelBasico;
    public double suelTotal;
    public String cedula;

    public Profesor(String nombre, String apellido, double suelBasico, String cedula) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.suelBasico = suelBasico;
        this.suelTotal = calcularSuelTotal();
        this.cedula = cedula;
    }

    public final double calcularSuelTotal() {
        return suelBasico * 1.20;
    }

    @Override
    public String toString() {
        return "Nombre del Docente: " + nombre + "\nApellido del Docente: " + apellido+ "\nCedula: " + cedula+ "\nSueldo Basico: $" + suelBasico+ "\nSueldo Total: $" + suelTotal;
    }
}
