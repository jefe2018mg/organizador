
package poo7;

public class Ejecutor {

    public static void main(String[] args) {
        Automotor automotor = new Automotor("984321", "Porch", 2010, 65000000);

        System.out.println(automotor);

    }
}

class Automotor {

    public String ceduDueño;
    public String marVehiculo;
    public int añoFabri;
    public double valVehiculo;
    public double valMatricula;

    public Automotor(String cedulaDueño, String marVehiculo, int añoFabri, double valVehiculo) {
        this.ceduDueño = cedulaDueño;
        this.marVehiculo = marVehiculo;
        this.añoFabri = añoFabri;
        this.valVehiculo = valVehiculo;
        this.valMatricula = calcularValMatricula();
    }

    private double calcularValMatricula() {
        int añosAntiguedad = 2023 - añoFabri; 
        double porcentajeMatricula = 0.002 * añosAntiguedad;
        return valVehiculo * porcentajeMatricula;
    }

    public String toString() {
        return String.format("Cedula del Dueno del Vehiculo: %s\n" + "Marca del Vehiculo: %s\nAno de Fabricacion del Vehiculo:%d\n"+ "Valor del Vehiculo:%.2f\nValor de la Matricula del Vehiculo: %.2f",ceduDueño, marVehiculo, añoFabri, valVehiculo, valMatricula);
    }
}
