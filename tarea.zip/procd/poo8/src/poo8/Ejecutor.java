
package poo8;

import java.util.Random;

public class Ejecutor {

    public static void main(String[] args) {
        String nombreCliente = gerNomAleatorio();
        String nombreBanco = gerNomBancoAleatorio();
        double valCheque = gerValAleatorio(100, 10000);

        Cheque cheque = new Cheque(nombreCliente, nombreBanco, valCheque);

        System.out.println(cheque);
    }

    public static String gerNomAleatorio() {
        String[] nombres = {"jose", "pablo", "andres", "pedro", "jeis", "juan", "carlos", "lucas", "kico", "penelope"};
        String[] apellidos = {"joan", "genry", "pineda", "samaniego", "lolita", "tonci", "maci", "raquel", "santiago", "sofi"};

        Random rand = new Random();
        String nombre = nombres[rand.nextInt(nombres.length)];
        String apellido = apellidos[rand.nextInt(apellidos.length)];

        return nombre + " " + apellido;
    }

    public static String gerNomBancoAleatorio() {
        String[] bancos = {"Banco Nacional", "Banco Central", "Banco Internacional", "Banco Regional", "Banco Global"};
        Random rand = new Random();
        return bancos[rand.nextInt(bancos.length)];
    }

    public static double gerValAleatorio(double min, double max) {
        Random rand = new Random();
        return min + (max - min) * rand.nextDouble();
    }
}

class Cheque {

    public String nomCliente;
    public String nomBanco;
    public double valCheque;
    public double comisionBanco;

    public Cheque(String nombreCliente, String nombreBanco, double valorCheque) {
        this.nomCliente = nombreCliente;
        this.nomBanco = nombreBanco;
        this.valCheque = valorCheque;
        this.comisionBanco = calcularComisionBanco();
    }

    public final double calcularComisionBanco() {
        return valCheque * 0.003; // 
    }

    @Override
    public String toString() {
        return String.format("Nombre del cliente: %s \n" + "Nombre del Banco: %s\nValor del Cheque: %.2f\n"+ "Comision del Banco: %.2f", nomCliente, nomBanco, valCheque,comisionBanco);
    }
}
